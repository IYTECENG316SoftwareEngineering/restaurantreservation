<?php

/**
 * Description of CalcuTest
 *
 * @author Can
 */
require_once '..\Rest.php';

class RestTest extends PHPUnit_Framework_TestCase {

    
    public function testAverage() {
        $b = new Rest();
        $this->assertEquals(2, $b->average(10, 5));
    }
    
       //design to fail
      public function testFailAverage()
    {
        $a = new Rest();
        $this->assertEquals(4, $a->average(15, 5));
        
    }
    
    //printStars Function has one float variable that has to be between 0-5
     public function testPrintStars()
    {
        $a = new Rest();
        $this->assertLessThanOrEqual(5, 3);
        $this->assertGreaterThanOrEqual(0, 3);      
    }
    
    

}
