<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Money
 *
 * @author Can
 */
class Rest {
    
   function average($total, $counter)
	{
			$result = $total/$counter;
			$avg = sprintf("%.1f", $result);

			return $avg;

	}
        
        function printstars($average)
	{

		if($average > 0 && $average < 0.6)
		{

			echo "<img  width = 25px src = 'starhalf.jpg' alt = ''>";
		}

		else if($average  > 0.59 && $average < 1.25){

			echo "<img  width = 25px src = 'star.jpg' alt = ''>";

		}

		else if($average  > 1.24 && $average < 1.75){

			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'starhalf.jpg' alt = ''>";

		}

		else if($average  > 1.74 && $average < 2.25){

			echo "<img  width = 25px src = 'star.jpg' alt = '''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";

		}

		else if($average  > 2.24 && $average < 2.75){

			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'starhalf.jpg' alt = ''>";

		}


		else if($average  > 2.74 && $average < 3.25){

			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = '''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";

		}

		else if($average  > 3.24 && $average < 3.75){

			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 12px src = 'starhalf.jpg' alt = ''>";

		}

		else if($average  > 3.74 && $average < 4.25){

			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = '' >";
			echo "<img  width = 25px src = 'star.jpg' alt = '' >";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";

		}

		else if($average  > 4.24 && $average < 4.75){

			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'starhalf.jpg' alt = '''>";

		}

		else
		{
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";
			echo "<img  width = 25px src = 'star.jpg' alt = ''>";

		}

	}
        
}
